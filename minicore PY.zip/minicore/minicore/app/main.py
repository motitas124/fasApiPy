import os
from datetime import date
from typing import Dict

from fastapi import FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.models import usuarios, ventas

# Inicializa la aplicación FastAPI (maneja todas las rutas y endpoints)
app = FastAPI(title="MiniCore - Sistema de Cálculo de Comisiones")

# Configuración de CORS: "*" permite acceso desde cualquier origen
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Reglas de comisión: (límite mínimo de ventas, porcentaje), de mayor a menor
REGLAS_COMISION = [
    (1000, 0.15),
    (800, 0.10),
    (600, 0.08),
    (400, 0.06),
]


def obtener_porcentaje(total_ventas: float) -> float:
    """Devuelve el primer porcentaje cuyo límite sea <= total. Si no cumple ninguna, 0."""
    for limite, porcentaje in REGLAS_COMISION:
        if total_ventas >= limite:
            return porcentaje
    return 0.0


@app.get("/comision")
def calcular_comision(
    fecha_inicio: date = Query(..., description="Fecha de inicio (YYYY-MM-DD)"),
    fecha_fin: date = Query(..., description="Fecha de fin (YYYY-MM-DD)"),
):
    # Acumula las ventas por vendedor dentro del rango de fechas
    totales: Dict[int, float] = {}
    for venta in ventas:
        if fecha_inicio <= venta["fecha"] <= fecha_fin:
            uid = venta["usuario_id"]
            totales[uid] = totales.get(uid, 0) + venta["monto"]

    # Calcula la comisión de cada usuario
    resultado = []
    for usuario in usuarios:
        total = totales.get(usuario["id"], 0)
        porcentaje = obtener_porcentaje(total)
        comision = round(total * porcentaje, 2)
        resultado.append(
            {
                "usuario": usuario["nombre"],
                "total_ventas": total,
                "porcentaje_aplicado": porcentaje,
                "comision_calculada": comision,
            }
        )

    return {
        "rango": {"desde": fecha_inicio, "hasta": fecha_fin},
        "resultado": resultado,
    }


# Montaje del frontend (mismo servicio para API + frontend, útil para el deploy)
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")


# Manejo de rutas SPA: devuelve index.html para rutas no definidas
@app.get("/{full_path:path}")
async def spa_catch_all(request: Request, full_path: str):
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))
