from datetime import date

# Vendedores
usuarios = [
    {"id": 1, "nombre": "juan"},
    {"id": 2, "nombre": "carlos"},
    {"id": 3, "nombre": "mateo"},
    {"id": 4, "nombre": "ana"},
]

# Ventas realizadas (datos en memoria)
ventas = [
    {"usuario_id": 1, "monto": 400.0, "fecha": date(2025, 5, 21)},
    {"usuario_id": 1, "monto": 300.0, "fecha": date(2025, 6, 9)},
    {"usuario_id": 1, "monto": 500.0, "fecha": date(2025, 6, 24)},
    {"usuario_id": 2, "monto": 600.0, "fecha": date(2025, 5, 29)},
    {"usuario_id": 2, "monto": 200.0, "fecha": date(2025, 6, 3)},
    {"usuario_id": 3, "monto": 900.0, "fecha": date(2025, 6, 11)},
    {"usuario_id": 4, "monto": 600.0, "fecha": date(2025, 6, 30)},
]
