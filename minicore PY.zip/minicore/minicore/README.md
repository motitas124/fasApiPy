# MiniCore - Sistema de Cálculo de Comisiones

Backend FastAPI + frontend Vue 3 (servido por el mismo servicio).

## Requisitos
- Python 3.10+ (probado con la versión pineada en requirements.txt)
- Un navegador con acceso a internet (Vue se carga desde unpkg CDN)

## Ejecutar en local
```bash
python -m venv venv
# Linux/macOS:
source venv/bin/activate
# Windows (PowerShell):
# venv\Scripts\Activate.ps1

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Abre http://localhost:8000 (interfaz) o http://localhost:8000/docs (Swagger).

## API
```bash
curl "http://localhost:8000/comision?fecha_inicio=2025-06-01&fecha_fin=2025-06-30"
```

## Reglas de comisión
| Ventas totales | Comisión |
|---|---|
| >= 1000 | 15% |
| >= 800 | 10% |
| >= 600 | 8% |
| >= 400 | 6% |
| < 400 | 0% |

## Deploy en Render
Usa `render.yaml` (start: `uvicorn app.main:app --host 0.0.0.0 --port 10000`)
o crea un Web Service con Build `pip install -r requirements.txt`
y Start `uvicorn app.main:app --host 0.0.0.0 --port $PORT`.
